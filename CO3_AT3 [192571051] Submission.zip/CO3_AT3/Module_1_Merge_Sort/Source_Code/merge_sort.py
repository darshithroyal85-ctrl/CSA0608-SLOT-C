"""Stable merge sort for KartIQ orders. Each order is (timestamp, order_id)."""
def merge_sort_orders(orders):
    """Return a stable timestamp-sorted copy; input order breaks timestamp ties."""
    if len(orders) <= 1:
        return list(orders)
    mid = len(orders) // 2
    left = merge_sort_orders(orders[:mid])
    right = merge_sort_orders(orders[mid:])
    return _merge(left, right)

def _merge(left, right):
    merged, i, j = [], 0, 0
    while i < len(left) and j < len(right):
        # <= is essential: equal timestamps from the left (earlier arrival) stay first.
        if left[i][0] <= right[j][0]:
            merged.append(left[i]); i += 1
        else:
            merged.append(right[j]); j += 1
    merged.extend(left[i:]); merged.extend(right[j:])
    return merged

if __name__ == '__main__':
    sample=[(105,'O1'),(102,'O2'),(105,'O3'),(101,'O4'),(102,'O5'),(103,'O6')]
    print('Input:', sample)
    print('Sorted:', merge_sort_orders(sample))
