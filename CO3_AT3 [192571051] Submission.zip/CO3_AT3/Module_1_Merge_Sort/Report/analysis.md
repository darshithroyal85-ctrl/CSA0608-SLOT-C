# Module 1 — Nightly Order Consolidation

## Requirement and design
Sort `(timestamp, order_id)` ascending by timestamp, preserving arrival order for ties. Stable Merge Sort is selected.

## Divide, conquer, combine trace
Input: `[(105, 'O1'), (102, 'O2'), (105, 'O3'), (101, 'O4'), (102, 'O5'), (103, 'O6')]`

- Divide: `[(105,O1),(102,O2),(105,O3)]` and `[(101,O4),(102,O5),(103,O6)]`; recursively split to singleton lists.
- Merge left half: `[(102,O2),(105,O1),(105,O3)]` (O1 remains before O3 for equal timestamp).
- Merge right half: `[(101,O4),(102,O5),(103,O6)]`.
- Final merge: `[(101, 'O4'), (102, 'O2'), (102, 'O5'), (103, 'O6'), (105, 'O1'), (105, 'O3')]`.

## Recurrence and complexity
`T(n)=2T(n/2)+cn`, `T(1)=d`. By the Master Theorem, `T(n)=Θ(n log₂ n)`. Auxiliary memory is `Θ(n)` plus `Θ(log n)` recursion stack. A rough comparison estimate for n=10,000,000 is `n log₂ n − n + 1 ≈ 222,534,967` comparisons; actual counts depend on data.

## Production note
If data exceeds RAM, use external merge sort: sort memory-sized runs, write them to disk, then perform a k-way merge.
