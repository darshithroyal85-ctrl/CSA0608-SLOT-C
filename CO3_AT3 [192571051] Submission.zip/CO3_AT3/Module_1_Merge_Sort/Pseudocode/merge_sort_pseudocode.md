# Stable Merge Sort pseudocode
```text
MERGE_SORT(A):
  if length(A) <= 1: return A
  split A into L and R at midpoint
  L = MERGE_SORT(L)             // conquer left half
  R = MERGE_SORT(R)             // conquer right half
  return MERGE(L, R)            // combine in timestamp order
MERGE(L, R):
  while both halves nonempty:
    if L[0].timestamp <= R[0].timestamp: append/remove first L
    else: append/remove first R
  append remaining items
  return merged
```
Tie rule: choose the left element on equality to preserve arrival order.
