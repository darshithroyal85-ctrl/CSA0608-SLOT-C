# Module 3 — Order Lookup

## Requirement
Find the first order with a target timestamp in the sorted list. Binary search requires the nondecreasing timestamp order produced by Module 1.

Sorted sample: `[(101, 'O4'), (102, 'O2'), (102, 'O5'), (103, 'O6'), (105, 'O1'), (105, 'O3')]`. Target 102 returns index 1 (O2), target 104 returns -1, and target 105 returns index 4 (O1).

## Recurrence and complexity
`T(n)=T(n/2)+c`, `T(1)=d`; therefore `T(n)=Θ(log n)`. For 10,000,000 orders, maximum binary-search iterations/comparisons are bounded by `ceil(log₂(n+1)) = 24` (implementation-specific comparison count may differ by a small constant). Extra space is `O(1)` for iterative search. The implementation records a match and continues left to return the first duplicate.
