"""Binary search for the first order matching a timestamp."""
def first_timestamp(orders, target):
    """Return the index of the first target timestamp, or -1 if absent.
    Precondition: orders is sorted by timestamp in nondecreasing order.
    """
    lo, hi = 0, len(orders)-1
    answer=-1
    while lo <= hi:
        mid=(lo+hi)//2
        if orders[mid][0] >= target:
            if orders[mid][0] == target: answer=mid
            hi=mid-1
        else:
            lo=mid+1
    return answer

if __name__ == '__main__':
    orders=[(101,'O4'),(102,'O2'),(102,'O5'),(103,'O6'),(105,'O1'),(105,'O3')]
    for t in (102,104,105): print(f'{t} -> index {first_timestamp(orders,t)}')
