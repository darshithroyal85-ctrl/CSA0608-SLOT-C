# First-occurrence Binary Search pseudocode
```text
FIRST_TIMESTAMP(A, target):
  lo = 0; hi = length(A)-1; answer = -1
  while lo <= hi:
    mid = floor((lo+hi)/2)
    if A[mid].timestamp >= target:
      if equal: answer = mid
      hi = mid-1
    else: lo = mid+1
  return answer
```
Precondition: A is sorted by timestamp. The leftward search after a match finds the first duplicate.
