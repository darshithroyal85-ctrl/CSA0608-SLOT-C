# Final Design and Analysis — KartIQ CO3 AT3

## (a) Case understanding
| Module | Requirement | Main risk | Selected design |
|---|---|---|---|
| 1. Order consolidation | Stable sort by timestamp for 10 million orders | Unstable tie handling; RAM limits | Stable Merge Sort; external merge sort if data exceeds RAM |
| 2. Seller leaderboard | Re-sort 100,000 scores, often nearly sorted | First pivot causes skewed partitions and O(n²) time | Median-of-three, 3-way Quick Sort; consider incremental updates or introsort |
| 3. Order lookup | Find first matching timestamp | Binary search on unsorted data is invalid; duplicates need leftmost match | Iterative lower-bound style binary search |
| 4. Recommendation scores | Multiply 1,024×1,024 matrices | Cubic multiplication cost and temporary memory | Strassen above tuned threshold, conventional multiplication below it |

## (b) Merge Sort
Stable merge sort divides the list into halves, recursively sorts each half, and merges sorted halves by repeatedly taking the smaller timestamp. On equality, take from the left half to preserve original arrival order. For the sample, output is `[(101, 'O4'), (102, 'O2'), (102, 'O5'), (103, 'O6'), (105, 'O1'), (105, 'O3')]`. Recurrence `T(n)=2T(n/2)+Θ(n)` solves to `Θ(n log n)`. At 10,000,000 entries, a rough comparison estimate is about 223 million. Extra memory `Θ(n)`; use external multiway merge if RAM is insufficient.

## (c) Quick Sort
Sample `[42,17,63,8,55,29]` sorts to `[8,17,29,42,55,63]`. A first-element pivot can produce highly unbalanced partitions on ordered input. Balanced recurrence `2T(n/2)+Θ(n)` gives `Θ(n log n)`; worst recurrence `T(n−1)+Θ(n)` gives `Θ(n²)`. At 100,000 entries, worst-case pairwise comparison count is approximately 4,999,950,000. Median-of-three and 3-way partition reduce common failures, but a worst-case-safe introsort is a stronger production choice.

## (d) Binary Search
The input must already be sorted by timestamp. Recurrence `T(n)=T(n/2)+Θ(1)` gives `Θ(log n)` and iterative extra space `Θ(1)`. For 10,000,000 orders, `ceil(log₂(n+1))=24` iterations is a conservative upper bound. To return the first duplicate, after a match record the index and continue searching left.

## (e) Strassen
Use the seven products and reconstruction formulas in Module 4. For sample matrices the product is `[[50,38],[38,34]]`. Recurrence `T(n)=7T(n/2)+Θ(n²)` gives `Θ(n^2.8074)`. At n=1,024, ideal multiplication counts are 282,475,249 (Strassen) vs 1,073,741,824 (conventional). This is a theoretical count, not a runtime guarantee; additions, memory allocation, data movement and numerical considerations matter. Use a hybrid cutoff determined by benchmark.

## (f) Final recommendations and trade-offs
- **Merge Sort:** stable `Θ(n log n)`, `Θ(n)` auxiliary memory. Change to external merge sort when data exceeds memory.
- **Quick Sort:** expected `Θ(n log n)`, in-place array storage plus stack. For strict worst-case guarantees, use introsort. Nearly-sorted low-volume updates may be better handled incrementally.
- **Binary Search:** `Θ(log n)`, `Θ(1)` extra space, but requires sorted timestamps. If lookups dominate and data changes frequently, maintain a timestamp index.
- **Strassen:** `Θ(n^2.8074)` asymptotically, but extra temporary matrices. Use conventional multiplication for small matrices and switch at a measured cutoff.

## Verification
The included test harness verifies stable ties, empty/singleton inputs, duplicate quick-sort values, missing timestamps, first duplicate lookup, 1×1 multiplication, sample matrices, and random matrices. Execution output is recorded in `Supporting_Files/execution_log.txt`.
