"""Integrated tests for all four KartIQ modules."""
import sys, random
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'Module_1_Merge_Sort/Source_Code'))
sys.path.insert(0,str(ROOT/'Module_2_Quick_Sort/Source_Code'))
sys.path.insert(0,str(ROOT/'Module_3_Binary_Search/Source_Code'))
sys.path.insert(0,str(ROOT/'Module_4_Strassen_Matrix_Multiplication/Source_Code'))
from merge_sort import merge_sort_orders
from quick_sort import quick_sort_scores
from binary_search import first_timestamp
from strassen import strassen

def run_tests():
    orders=[(105,'O1'),(102,'O2'),(105,'O3'),(101,'O4'),(102,'O5'),(103,'O6')]
    assert merge_sort_orders(orders)==[(101,'O4'),(102,'O2'),(102,'O5'),(103,'O6'),(105,'O1'),(105,'O3')]
    assert merge_sort_orders([])==[] and merge_sort_orders([(1,'x')])==[(1,'x')]
    assert quick_sort_scores([42,17,63,8,55,29])==[8,17,29,42,55,63]
    assert quick_sort_scores([])==[] and quick_sort_scores([2,2,1,2])==[1,2,2,2]
    sorted_orders=merge_sort_orders(orders)
    assert first_timestamp(sorted_orders,102)==1
    assert first_timestamp(sorted_orders,104)==-1
    assert first_timestamp([],1)==-1
    assert strassen([[1,7],[3,5]],[[1,3],[7,5]],cutoff=1)==[[50,38],[38,34]]
    assert strassen([[2]],[[4]])==[[8]]
    rng=random.Random(7)
    for n in (1,2,3,5,8):
        x=[[rng.randrange(10) for _ in range(n)] for _ in range(n)]
        y=[[rng.randrange(10) for _ in range(n)] for _ in range(n)]
        expected=[[sum(x[i][k]*y[k][j] for k in range(n)) for j in range(n)] for i in range(n)]
        assert strassen(x,y,cutoff=2)==expected
    print('PASS: merge sort sample + boundaries + stable ties')
    print('PASS: quick sort sample + empty + duplicates')
    print('PASS: binary search first duplicate + missing + empty')
    print('PASS: Strassen sample + 1x1 + random matrix checks')
    print('ALL TESTS PASSED')
if __name__=='__main__': run_tests()
