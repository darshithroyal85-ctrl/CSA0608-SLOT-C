"""Strassen matrix multiplication with a conventional small-matrix cutoff."""
def _add(A,B): return [[A[i][j]+B[i][j] for j in range(len(A))] for i in range(len(A))]
def _sub(A,B): return [[A[i][j]-B[i][j] for j in range(len(A))] for i in range(len(A))]
def _naive(A,B):
    n=len(A); return [[sum(A[i][k]*B[k][j] for k in range(n)) for j in range(n)] for i in range(n)]
def _split(A):
    n=len(A)//2
    return ([r[:n] for r in A[:n]], [r[n:] for r in A[:n]], [r[:n] for r in A[n:]], [r[n:] for r in A[n:]])
def _join(C11,C12,C21,C22):
    n=len(C11); top=[C11[i]+C12[i] for i in range(n)]; bot=[C21[i]+C22[i] for i in range(n)]; return top+bot

def strassen(A,B,cutoff=32):
    """Multiply square, equal-size matrices. Pads to power of two; strips padding on return."""
    if not A or not B or len(A)!=len(A[0]) or len(B)!=len(B[0]) or len(A)!=len(B):
        raise ValueError('A and B must be non-empty square matrices of equal size')
    n=len(A); size=1
    while size<n: size*=2
    Ap=[list(row)+[0]*(size-n) for row in A]+[[0]*size for _ in range(size-n)]
    Bp=[list(row)+[0]*(size-n) for row in B]+[[0]*size for _ in range(size-n)]
    def rec(X,Y):
        m=len(X)
        if m<=cutoff: return _naive(X,Y)
        A11,A12,A21,A22=_split(X); B11,B12,B21,B22=_split(Y)
        M1=rec(_add(A11,A22),_add(B11,B22))
        M2=rec(_add(A21,A22),B11)
        M3=rec(A11,_sub(B12,B22))
        M4=rec(A22,_sub(B21,B11))
        M5=rec(_add(A11,A12),B22)
        M6=rec(_sub(A21,A11),_add(B11,B12))
        M7=rec(_sub(A12,A22),_add(B21,B22))
        C11=_add(_sub(_add(M1,M4),M5),M7)
        C12=_add(M3,M5)
        C21=_add(M2,M4)
        C22=_add(_sub(_add(M1,M3),M2),M6)
        return _join(C11,C12,C21,C22)
    full=rec(Ap,Bp)
    return [row[:n] for row in full[:n]]

if __name__ == '__main__':
    A=[[1,7],[3,5]]; B=[[1,3],[7,5]]
    print('A =',A); print('B =',B); print('A x B =',strassen(A,B,cutoff=1))
