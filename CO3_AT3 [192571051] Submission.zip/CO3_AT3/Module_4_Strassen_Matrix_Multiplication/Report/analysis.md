# Module 4 — Strassen Recommendation Scores

## Seven products
`M1=(A11+A22)(B11+B22)`; `M2=(A21+A22)B11`; `M3=A11(B12−B22)`; `M4=A22(B21−B11)`; `M5=(A11+A12)B22`; `M6=(A21−A11)(B11+B12)`; `M7=(A12−A22)(B21+B22)`.

## Reconstruction
`C11=M1+M4−M5+M7`; `C12=M3+M5`; `C21=M2+M4`; `C22=M1−M2+M3+M6`.

For `A=[[1, 7], [3, 5]]` and `B=[[1, 3], [7, 5]]`, the result is `C=[[50, 38], [38, 34]]`. Conventional multiplication verifies the same result.

## Recurrence and production calculation
`T(n)=7T(n/2)+Θ(n²)`, so `T(n)=Θ(n^(log₂7))≈Θ(n^2.8074)`. For n=1,024=2^10, the ideal recursive scalar multiplication count is `7^10=282,475,249` versus conventional `n³=1,073,741,824`. This ideal count excludes additions, memory traffic, padding and cutoff effects. Strassen can lose on small/medium matrices due to additions and allocation overhead, numerical growth, and memory pressure. Use a hybrid cutoff (conventional multiplication below a tuned threshold); benchmark on the actual hardware.
