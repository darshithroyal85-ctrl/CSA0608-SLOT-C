# Module 2 — Live Seller Leaderboard

## Requirement and trace
Sample: `[42, 17, 63, 8, 55, 29]`; sorted output: `[8, 17, 29, 42, 55, 63]`. One Lomuto-style partition trace using first pivot 42 (illustrative partition variant): scan the remaining values and place values below pivot to its left; values above it to the right. The first-pivot approach is vulnerable when input is already sorted or nearly sorted: partitions can become 0 and n−1.

## Recurrences
Balanced best/expected partition: `T(n)=2T(n/2)+cn = Θ(n log n)`. Worst case: `T(n)=T(n−1)+cn = Θ(n²)`, with roughly `n(n−1)/2` comparisons. For 100,000 sellers, worst-case comparisons are about 4,999,950,000; balanced-order estimate `n log₂n ≈ 1,660,964` (constant factors omitted).

## Improvement and trade-off
Use median-of-three pivoting and 3-way partitioning; implementation recurses into the smaller side to limit stack depth. Expected time is `O(n log n)`, worst case remains `O(n²)`; introsort or randomized pivoting gives stronger worst-case protection. Since only a few scores change between refreshes, an incremental ordered structure or sorting only changed entries may be preferable if update volume is consistently small.
