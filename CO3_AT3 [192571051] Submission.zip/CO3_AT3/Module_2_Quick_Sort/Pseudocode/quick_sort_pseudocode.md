# Improved Quick Sort pseudocode
```text
QUICK_SORT(A, lo, hi):
  while lo < hi:
    pivot = median(A[lo], A[mid], A[hi])
    partition into < pivot, = pivot, > pivot (Dutch-national-flag partition)
    recurse on the smaller outer partition
    continue loop on the larger outer partition
```
Median-of-three reduces sorted-input pivot failures; three-way partition handles duplicate scores. Worst case remains O(n^2), but randomized pivoting or introsort can provide stronger safeguards.
