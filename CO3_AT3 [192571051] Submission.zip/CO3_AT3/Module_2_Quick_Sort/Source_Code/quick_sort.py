"""Quick sort using median-of-three pivot and 3-way partitioning."""
def quick_sort_scores(values):
    """Return sorted copy. Median-of-three reduces bad pivot risk; 3-way partition handles duplicates."""
    a=list(values)
    def sort(lo, hi):
        while lo < hi:
            mid=(lo+hi)//2
            pivot=sorted((a[lo],a[mid],a[hi]))[1]
            lt, i, gt=lo, lo, hi
            while i <= gt:
                if a[i] < pivot:
                    a[lt],a[i]=a[i],a[lt]; lt+=1; i+=1
                elif a[i] > pivot:
                    a[i],a[gt]=a[gt],a[i]; gt-=1
                else: i+=1
            # Recurse into smaller side, loop over larger side to bound stack depth.
            if lt-lo < hi-gt:
                sort(lo,lt-1); lo=gt+1
            else:
                sort(gt+1,hi); hi=lt-1
    sort(0,len(a)-1)
    return a

if __name__ == '__main__':
    sample=[42,17,63,8,55,29]
    print('Input:',sample)
    print('Sorted:',quick_sort_scores(sample))
