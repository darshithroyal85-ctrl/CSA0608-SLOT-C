# CO3_AT3 — KartIQ Divide-and-Conquer Case Study

This repository contains the case study solution for CSA06 CO3: stable Merge Sort, improved Quick Sort, first-occurrence Binary Search, and Strassen Matrix Multiplication.

## Structure
- `Module_1_Merge_Sort/`: pseudocode, executable Python source, module report
- `Module_2_Quick_Sort/`: pseudocode, executable Python source, module report
- `Module_3_Binary_Search/`: pseudocode, executable Python source, module report
- `Module_4_Strassen_Matrix_Multiplication/`: pseudocode, executable Python source, module report
- `Final_Design_and_Analysis/`: integrated case analysis and recommendations
- `Supporting_Files/`: test harness, logs, CSV estimates, graphs and source/output evidence images

## Run the programs
Use Python 3.10+ (no third-party runtime dependencies for algorithms):
```bash
python Module_1_Merge_Sort/Source_Code/merge_sort.py
python Module_2_Quick_Sort/Source_Code/quick_sort.py
python Module_3_Binary_Search/Source_Code/binary_search.py
python Module_4_Strassen_Matrix_Multiplication/Source_Code/strassen.py
python Supporting_Files/test_harness.py
```
Expected test harness ending: `ALL TESTS PASSED`.

## Notes
- Merge Sort is stable: the merge uses `<=` so equal timestamps preserve arrival order.
- Quick Sort uses median-of-three and 3-way partitioning. Its theoretical worst case remains O(n²); introsort is suggested where strict protection is required.
- Binary Search expects a timestamp-sorted list and returns the first matching index or -1.
- Strassen pads matrices to a power of two and switches to conventional multiplication below a configurable cutoff.
- Benchmark estimates are theoretical estimates; measured wall-clock performance depends on hardware, Python version, data distribution and memory.

## GitHub upload
Create a repository, extract this folder, then run `git add CO3_AT3 && git commit -m "Add CO3 divide-and-conquer case study" && git push`.
