# CO2 – SentinelOps Debugging and Optimisation

**Course:** CSA06 – Design and Analysis of Algorithms  
**Assessment:** CO2 Debugging and Optimisation Task (50 marks)

This repository follows the supplied four-page assignment brief and contains all five requested parts: defect reproduction, root-cause debugging, optimisation, complexity/experimental analysis, and production-quality code.

## Repository layout
- `Pseudocode/` – separate pseudocode for the four functions.
- `Source_Code/original_buggy.py` – faithful transcription of the supplied buggy module and its test data.
- `Source_Code/corrected_reference.py` – minimally corrected, straightforward algorithms.
- `Source_Code/optimized_module.py` – optimised implementations.
- `Source_Code/test_harness.py` – unit and boundary tests.
- `Report/` – full report, graphs, and screenshot-like source/output evidence.
- `Supporting_Files/` – generated test datasets, CSV benchmark results, and execution logs.

## Run
Python 3.10+ recommended. From `Source_Code/` run:
```bash
python test_harness.py
python original_buggy.py
python run_experiments.py
```
The `original_buggy.py` program is intentionally faulty; its errors are documented in the report. For repeatable benchmark data, use `Supporting_Files/run_experiments.py` from the repository root.

## Important behaviour choices
- Equal-severity alerts retain arrival order (stable descending sort).
- Blocklist membership returns `True` when an IP is present.
- String matching reports all matches, including overlaps. Empty pattern returns all `n+1` boundaries.
- Closest-pair output uses original input indices; fewer than two points returns `(None, infinity)`.
- The active-window closest-pair method has an O(n²) worst case but prunes many comparisons on typical spatial data. It is not claimed to be worst-case O(n log n).

## Reproducibility
Benchmark data is generated with a fixed random seed and included in `Supporting_Files/`. Runtime measurements vary by machine and Python version; distance-computation counts are more reproducible than wall-clock time.
