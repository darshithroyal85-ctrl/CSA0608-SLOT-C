"""Optimised SentinelOps SOC alert-triage algorithms."""
import math

def sort_alerts(alerts):
    """Stable descending severity sort; Python's Timsort is efficient for nearly sorted data."""
    return sorted(alerts, key=lambda alert: alert[1], reverse=True)

def is_blocked(blocklist, ip):
    """Membership query; pass a set for average O(1) repeated lookups."""
    return ip in blocklist

def find_signature(log, pattern):
    """Brute-force all-occurrence matching with early mismatch exit and safe bounds."""
    n, m = len(log), len(pattern)
    if m == 0:
        return list(range(n + 1))
    if m > n:
        return []
    hits = []
    last = n - m
    for i in range(last + 1):
        j = 0
        while j < m and log[i + j] == pattern[j]:
            j += 1
        if j == m:
            hits.append(i)
    return hits

def closest_logins(events):
    """Closest pair via x-sorted active window; returns original input indices and distance.

    The x-window and y-gap tests avoid distance evaluations for pairs that cannot
    improve the current best. Worst-case complexity remains O(n^2) for this simple
    active-list implementation, but random spatial batches prune heavily.
    """
    n = len(events)
    if n < 2:
        return None, math.inf
    points = sorted((x, y, i) for i, (x, y) in enumerate(events))
    best_sq = math.inf
    best_pair = None
    active = []
    for x, y, original_i in points:
        # Remove points too far apart horizontally to improve best_sq.
        active = [p for p in active if (x - p[0]) ** 2 < best_sq]
        for px, py, original_j in active:
            dy = y - py
            if dy * dy >= best_sq:
                continue
            dx = x - px
            d_sq = dx * dx + dy * dy
            if d_sq < best_sq:
                best_sq = d_sq
                best_pair = (min(original_i, original_j), max(original_i, original_j))
        active.append((x, y, original_i))
    return best_pair, math.sqrt(best_sq)
