import math, unittest
from corrected_reference import sort_alerts as corrected_sort, is_blocked as corrected_blocked, find_signature as corrected_find, closest_logins as corrected_closest
from optimized_module import sort_alerts, is_blocked, find_signature, closest_logins

class SentinelOpsTests(unittest.TestCase):
    def test_sort_stability_and_order(self):
        data=[('A1',3),('A2',9),('A3',5),('A4',9),('A5',1)]
        expected=[('A2',9),('A4',9),('A3',5),('A1',3),('A5',1)]
        self.assertEqual(sort_alerts(data), expected)
        self.assertEqual(corrected_sort(data.copy()), expected)
    def test_empty_sort(self): self.assertEqual(sort_alerts([]), [])
    def test_blocklist(self):
        b={'10.0.0.5','10.0.0.9','172.16.4.2'}
        self.assertTrue(is_blocked(b,'10.0.0.9'))
        self.assertFalse(is_blocked(b,'8.8.8.8'))
        self.assertFalse(is_blocked(set(),'8.8.8.8'))
        self.assertTrue(corrected_blocked(list(b),'10.0.0.5'))
    def test_signature(self):
        self.assertEqual(find_signature('FAILFAIXFAIL','FAIL'), [0,8])
        self.assertEqual(find_signature('ABC','BC'), [1])
        self.assertEqual(find_signature('ABC','ABCD'), [])
        self.assertEqual(find_signature('ABC',''), [0,1,2,3])
        self.assertEqual(find_signature('AAAA','AA'), [0,1,2])
        self.assertEqual(corrected_find('FAILFAIXFAIL','FAIL'), [0,8])
    def test_closest_pair(self):
        events=[(2,3),(12,30),(40,50),(5,1),(12,10),(3,4)]
        a=closest_logins(events); b=corrected_closest(events)
        self.assertEqual(a[0], (0,5)); self.assertAlmostEqual(a[1], math.sqrt(2))
        self.assertEqual(b[0], a[0]); self.assertAlmostEqual(b[1],a[1])
        self.assertEqual(closest_logins([]), (None, math.inf))
        self.assertEqual(closest_logins([(1,2)]), (None, math.inf))
        self.assertAlmostEqual(closest_logins([(0,0),(0,0)])[1],0.0)

if __name__ == '__main__': unittest.main(verbosity=2)
