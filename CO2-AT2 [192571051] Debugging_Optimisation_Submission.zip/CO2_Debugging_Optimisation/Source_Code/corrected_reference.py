"""Corrected SentinelOps algorithms; intentionally straightforward implementations."""
import math

def sort_alerts(alerts):
    """Stable insertion sort by severity descending; mutates and returns alerts."""
    for i in range(1, len(alerts)):
        key = alerts[i]
        j = i - 1
        while j >= 0 and alerts[j][1] < key[1]:
            alerts[j + 1] = alerts[j]
            j -= 1
        alerts[j + 1] = key
    return alerts

def is_blocked(blocklist, ip):
    """Return True iff ip occurs in blocklist using sequential search."""
    for item in blocklist:
        if item == ip:
            return True
    return False

def find_signature(log, pattern):
    """Return every start index where pattern occurs, including overlaps."""
    n, m = len(log), len(pattern)
    if m == 0:
        return list(range(n + 1))
    if m > n:
        return []
    hits = []
    for i in range(n - m + 1):
        j = 0
        while j < m and log[i + j] == pattern[j]:
            j += 1
        if j == m:
            hits.append(i)
    return hits

def closest_logins(events):
    """Return (index_pair, Euclidean_distance) for the closest distinct events.

    This corrected reference version checks each unordered pair once and compares
    squared distances, taking one square root only for the final result.
    """
    if len(events) < 2:
        return None, math.inf
    best_sq = math.inf
    pair = None
    for i in range(len(events) - 1):
        for j in range(i + 1, len(events)):
            dx = events[i][0] - events[j][0]
            dy = events[i][1] - events[j][1]
            d_sq = dx * dx + dy * dy
            if d_sq < best_sq:
                best_sq, pair = d_sq, (i, j)
    return pair, math.sqrt(best_sq)
