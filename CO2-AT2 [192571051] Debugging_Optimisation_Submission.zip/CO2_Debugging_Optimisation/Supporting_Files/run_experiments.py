import csv, math, random, time, sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'Source_Code'))
from corrected_reference import closest_logins as brute_closest, sort_alerts as insertion_sort
from optimized_module import closest_logins as pruned_closest

# Instrumented versions count actual squared-distance evaluations.
def brute_count(events):
    if len(events)<2: return 0
    count=0; best=float('inf')
    for i in range(len(events)-1):
        for j in range(i+1,len(events)):
            dx=events[i][0]-events[j][0]; dy=events[i][1]-events[j][1]
            d=dx*dx+dy*dy; count+=1
            if d<best: best=d
    return count

def pruned_count(events):
    if len(events)<2: return 0
    points=sorted((x,y,i) for i,(x,y) in enumerate(events)); active=[]; best=float('inf'); count=0
    for x,y,idx in points:
        active=[p for p in active if (x-p[0])**2<best]
        for px,py,j in active:
            dy=y-py
            if dy*dy>=best: continue
            dx=x-px; d=dx*dx+dy*dy; count+=1
            if d<best: best=d
        active.append((x,y,idx))
    return count

def insertion_count(a):
    a=a.copy(); comparisons=0
    for i in range(1,len(a)):
        key=a[i]; j=i-1
        while j>=0:
            comparisons+=1
            if a[j][1] < key[1]: a[j+1]=a[j]; j-=1
            else: break
        a[j+1]=key
    return comparisons

rng=random.Random(20261030)
rows=[]
for n in (1000,4000,8000):
    events=[(rng.random()*10000,rng.random()*10000) for _ in range(n)]
    t=time.perf_counter(); brute=brute_closest(events); brute_sec=time.perf_counter()-t
    t=time.perf_counter(); opt=pruned_closest(events); opt_sec=time.perf_counter()-t
    bc=brute_count(events); pc=pruned_count(events)
    rows.append({'experiment':'closest_pair','n':n,'brute_distance_computations':bc,'optimised_distance_computations':pc,'brute_seconds':round(brute_sec,6),'optimised_seconds':round(opt_sec,6),'notes':'fixed seed; uniform points in [0,10000)^2'})
for n in (100,500,1000):
    base=[(f'A{i}',rng.randrange(1,11)) for i in range(n)]
    cases={'sorted':sorted(base,key=lambda x:x[1]),'nearly_sorted':sorted(base,key=lambda x:x[1]),'random':base}
    # sorted descending is best case for descending insertion sort
    cases['sorted_desc']=sorted(base,key=lambda x:x[1],reverse=True)
    for name, arr in cases.items():
        rows.append({'experiment':'insertion_sort_comparisons','n':n,'brute_distance_computations':'','optimised_distance_computations':'','brute_seconds':'','optimised_seconds':'','notes':f'{name} comparisons={insertion_count(arr)}'})
out=Path(__file__).resolve().parent/'benchmark_results.csv'
with out.open('w',newline='',encoding='utf-8') as f:
    w=csv.DictWriter(f,fieldnames=rows[0].keys()); w.writeheader(); w.writerows(rows)
print('Benchmark results:',out)
for r in rows: print(r)
