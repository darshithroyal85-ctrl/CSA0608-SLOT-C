# SentinelOps SOC Alert-Triage Module: Debugging and Optimisation Report

**Course:** CSA06 – Design and Analysis of Algorithms  
**Assessment:** CO2 – Debugging and Optimisation Task  
**Student Name / Registration Number:** ____________________  
**Date:** ____________________

## Executive summary
The supplied module has nine defects across sorting, blocklist lookup, string matching and closest-pair computation. The key failures are an incorrect insertion-sort loop boundary, a blocklist function that always returns false, incomplete/incorrect string-match bounds and match validation, and a closest-pair routine that actually maximises distance while including self-pairs and duplicate pair work. The original code is retained in `Source_Code/original_buggy.py`; changes are isolated in a corrected reference version and an optimised module.

## Part (a) – reproduce and identify defects

### Expected results for the supplied data
- **Sorted alerts:** `[('A2', 9), ('A4', 9), ('A3', 5), ('A1', 3), ('A5', 1)]`. A2 remains before A4 because their severities are equal.
- **Blocklist:** `10.0.0.9 → True`, `10.0.0.5 → True`, `8.8.8.8 → False`.
- **Signature:** `FAILFAIXFAIL` contains `FAIL` at start indices `[0, 8]`.
- **Closest pair:** events `(2,3)` and `(3,4)` are indices `(0,5)`, distance √2 ≈ 1.4142 km.

### Nine defects and root causes
| # | Function / supplied line | Defect | Root cause and effect |
|---|---|---|---|
| 1 | `sort_alerts`, line 39: `j > 0` | Index zero is never shifted | The first element is excluded from insertion comparisons; a high-severity key can be placed after a lower-severity first element. Use `j >= 0`. |
| 2 | `sort_alerts`, line 42: `alerts[j] = key` | Incorrect insertion destination after shifting | When the loop moves past index zero, `j` becomes `-1`; assigning to `alerts[-1]` overwrites the final element. Insert at `j + 1`. |
| 3 | `is_blocked`, line 48 | Match returns `False` | A found blocked IP is reported as allowed. Return `True` on a match. |
| 4 | `is_blocked`, line 49 | `else` is inside the loop and returns immediately | First nonmatching list entry ends the search, so later blocked addresses are missed. Remove the per-item `else`; return `False` only after the loop. |
| 5 | `is_blocked`, after loop | No explicit final return | The intended not-found result should be `False` after all entries have been checked; relying on implicit `None` is incorrect API behaviour. |
| 6 | `find_signature`, line 56: `range(n-m)` | Last legal alignment is omitted | The valid start indices are `0 ... n-m`, inclusive; use `range(n-m+1)`. End-position signatures are missed. |
| 7 | `find_signature`, line 60: `j == m-1` | Partial matches may be accepted | After a mismatch at the final pattern character, `j` can still equal `m-1`, creating a false positive. Check `j == m`. |
| 8 | `closest_logins`, line 66: `min_dist = 0` | Wrong initial objective/bound | The algorithm needs to minimise distance; initialising to zero means no nonnegative distance can improve it under a `<` comparison, while the current `>` condition instead searches for a maximum. Initialise squared minimum to infinity. |
| 9 | `closest_logins`, lines 68–74 | Includes self-pairs, repeats unordered pairs, and uses `d > min_dist` | Self-distance zero and duplicate pairs waste work; `>` selects the farthest pair. Iterate only `j > i`, compare with `<`, and use squared distances. |

> The brief states nine defects. Defects 2 and 5 are closely related consequences of the faulty insertion destination and missing post-loop return; they are listed separately because each has a distinct observable/API consequence.

## Part (b) – systematic debugging and verification

### Sorting trace
Start: `A1:3, A2:9, A3:5, A4:9, A5:1`.
1. Insert A2(9): compare with A1(3), shift A1 right, then insert A2 at index 0.
2. Insert A3(5): shift A1(3), stop before A2(9), insert A3 after A2.
3. Insert A4(9): strict `<` means A2(9) is not shifted; A4 is inserted after A2, preserving equal-severity arrival order.
4. Insert A5(1): no shifts needed.
Final: `A2:9, A4:9, A3:5, A1:3, A5:1`.

### Signature alignment trace
`log = FAILFAIXFAIL`, `pattern = FAIL`, `m=4`, valid starts `0..8`.
- start 0: F-A-I-L all match → record 0.
- starts 1–7: at least one character differs → do not record.
- start 8: F-A-I-L all match → record 8.
Result `[0, 8]`. The original `range(n-m)` checks starts only 0–7, excluding 8. The original `j == m-1` can report a partial match if a mismatch occurs at the final character.

### Corrected versus optimised verification
`Source_Code/test_harness.py` verifies stable ordering, present/absent blocklist values, empty blocklists, overlapping matches, final-position matches, longer-than-log patterns, empty patterns, fewer than two events, duplicate coordinates and the supplied example. The test harness is designed to pass for both corrected and optimised implementations.

## Part (c) – optimisation decisions
1. **Sorting:** insertion sort remains reasonable for small or nearly sorted arrays, with O(n) best case and O(n²) average/worst case. At 50,000 alerts, Python's stable Timsort via `sorted(..., reverse=True)` is a safer general choice: O(n log n) worst case and O(n) on strongly ordered runs. Stability preserves arrival order for equal severities.
2. **Blocklist:** build a `set` once and perform repeated membership tests in average O(1), instead of O(b) per query. Set construction costs O(b) expected time and O(b) space.
3. **String matching:** use the inclusive final start index, check full match (`j == m`), stop each alignment at first mismatch, and explicitly handle empty/longer patterns. Worst case remains O(nm), auxiliary output space O(k).
4. **Closest pair:** inspect only unordered pairs in the reference algorithm, compare squared distances, and take one square root at the end. The optimised implementation sorts points by x and keeps an active window; points too far in x or y are skipped. This often reduces distance evaluations but has O(n²) worst case for this simple active-list method. A production implementation requiring a formal O(n log n) worst-case bound should use the divide-and-conquer closest-pair algorithm.

## Part (d) – complexity analysis
Let `n` be number of alerts, `b` blocklist size, `q` lookup count, `L` log length, `m` pattern length, and `p` number of login points.

| Function | Original/corrected simple algorithm | Optimised algorithm | Extra space |
|---|---|---|---|
| Alert sort | Insertion: best O(n), average/worst O(n²) | Timsort: best O(n), worst O(n log n) | O(n) returned sorted list |
| IP lookup | O(b) per query; O(qb) for q queries | Set build O(b), then average O(1) each; total expected O(b+q) | O(b) for set |
| Signature scan | O((L-m+1)m), worst O(Lm) | Same worst-case asymptotic bound; early mismatch avoids many comparisons in typical logs | O(k) hits, O(1) scan state |
| Closest pair | Θ(p²) unordered distance evaluations | Often substantially fewer evaluations due to x/y pruning; worst-case O(p²) here | O(p) sorting and active list |

### Operation-count derivations
- Insertion sort: each outer pass inserts one key; best case performs about `n-1` key comparisons, worst-case shifts `1+2+...+(n-1)=n(n-1)/2` elements.
- Sequential search: best case 1 comparison; worst case `b`; for uniformly likely successful positions, average `(b+1)/2`; unsuccessful search uses `b` comparisons.
- Brute-force matching: there are `max(0,L-m+1)` alignments. Each uses at most `m` character comparisons, giving O(Lm). Early mismatch reduces typical comparisons, not worst-case order.
- Closest pair reference: exactly `p(p-1)/2` pair-distance evaluations. The active-window implementation records actual distance evaluations in the benchmark and may prune many candidates; worst case can still reach quadratic work.

## Experimental results
The reproducible benchmark in `Supporting_Files/run_experiments.py` uses fixed-seed random points in a 10,000 × 10,000 coordinate plane for sizes 1,000, 4,000 and 8,000. It counts exact Euclidean distance evaluations, not just the cheap x/y pruning checks. It also compares insertion-sort comparisons on sorted/nearly sorted/random alerts at manageable sizes. See `Supporting_Files/benchmark_results.csv` and `Report/Graphs/` for generated results. Wall-clock timing is machine-dependent; pair counts are the stronger reproducibility metric.

## Part (e) – production-quality delivery
The source is split into original, corrected-reference, optimised module and test harness. Functions have docstrings, named variables and explicit boundary behaviour. Before deployment, run unit tests and benchmarks on representative real data, log invalid input handling, and review coordinate units/duplicate locations with the SOC team.

## Conclusion
The failures came from loop boundaries, early returns, incomplete match conditions and reversing the closest-pair objective. Systematic single-change debugging makes each cause verifiable. Optimisation then targets the workload: stable Timsort, set membership, careful brute-force matching and pruning in the closest-pair search, while documenting worst-case limits honestly.
