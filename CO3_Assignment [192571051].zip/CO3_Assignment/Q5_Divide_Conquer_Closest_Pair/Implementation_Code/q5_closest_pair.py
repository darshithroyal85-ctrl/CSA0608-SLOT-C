import math
def dist(p,q): return math.hypot(p[0]-q[0],p[1]-q[1])
def brute(points):
    best=float("inf"); pair=None
    for i in range(len(points)):
        for j in range(i+1,len(points)):
            d=dist(points[i],points[j])
            if d<best: best,pair=d,(points[i],points[j])
    return best,pair
def closest_pair(points):
    # Standard recursive split; strip checks at most next 7 points in y-order.
    px=sorted(points); py=sorted(points,key=lambda p:p[1])
    def rec(xs,ys):
        n=len(xs)
        if n<=3: return brute(xs)
        mid=n//2; xmid=xs[mid][0]
        leftx,rightx=xs[:mid],xs[mid:]
        leftset=set(leftx)
        lefty=[p for p in ys if p in leftset]
        righty=[p for p in ys if p not in leftset]
        dl,pl=rec(leftx,lefty); dr,pr=rec(rightx,righty)
        best,pair=(dl,pl) if dl<=dr else (dr,pr)
        strip=[p for p in ys if abs(p[0]-xmid)<best]
        for i in range(len(strip)):
            for j in range(i+1,min(i+8,len(strip))):
                d=dist(strip[i],strip[j])
                if d<best: best,pair=d,(strip[i],strip[j])
        return best,pair
    return rec(px,py)
if __name__=="__main__":
    pts=[(2,3),(12,30),(40,50),(5,1),(12,10),(3,4),(8,8),(9,9)]
    d1,p1=brute(pts); d2,p2=closest_pair(pts)
    print("Q5 Closest Pair of Points")
    print("Points:",pts)
    print(f"Brute force: distance={d1:.4f}, pair={p1}")
    print(f"Divide and Conquer: distance={d2:.4f}, pair={p2}")
    print("Correct distance:",abs(d1-d2)<1e-9)
    print("Complexity: brute force O(n^2); D&C O(n log n) with y-sorted strip processing.")
