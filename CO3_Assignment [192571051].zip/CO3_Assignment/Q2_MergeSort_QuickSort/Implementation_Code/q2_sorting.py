def merge_sort(a):
    if len(a)<=1: return a[:]
    mid=len(a)//2
    left,right=merge_sort(a[:mid]),merge_sort(a[mid:])
    out=[]; i=j=0
    while i<len(left) and j<len(right):
        if left[i]<=right[j]: out.append(left[i]); i+=1
        else: out.append(right[j]); j+=1
    return out+left[i:]+right[j:]
def quick_sort(a):
    if len(a)<=1: return a[:]
    pivot=a[len(a)//2]
    less=[x for x in a if x<pivot]
    equal=[x for x in a if x==pivot]
    greater=[x for x in a if x>pivot]
    return quick_sort(less)+equal+quick_sort(greater)
if __name__=="__main__":
    data=[29,10,14,37,13,5,42,18]
    print("Q2 Merge Sort vs Quick Sort")
    print("Input:",data)
    print("Merge Sort:",merge_sort(data))
    print("Quick Sort (middle-value pivot):",quick_sort(data))
    print("Complexity: Merge Sort O(n log n); Quick Sort average O(n log n), worst O(n^2).")
