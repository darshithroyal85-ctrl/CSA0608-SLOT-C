def max_min_dc(a, lo=0, hi=None):
    if hi is None: hi = len(a)-1
    if lo == hi: return a[lo], a[lo], 0
    if hi == lo+1:
        return max(a[lo], a[hi]), min(a[lo], a[hi]), 1
    mid=(lo+hi)//2
    mx1,mn1,c1=max_min_dc(a,lo,mid)
    mx2,mn2,c2=max_min_dc(a,mid+1,hi)
    return max(mx1,mx2), min(mn1,mn2), c1+c2+2
def binary_search(a, target):
    lo, hi, comparisons=0,len(a)-1,0
    while lo<=hi:
        mid=(lo+hi)//2; comparisons+=1
        if a[mid]==target: return mid,comparisons
        if a[mid]<target: lo=mid+1
        else: hi=mid-1
    return -1,comparisons
if __name__=="__main__":
    data=[14, 3, 27, -2, 19, 8, 31, 5]
    mx,mn,c=max_min_dc(data)
    print("Q1 Max/Min using Divide and Conquer")
    print(f"Data: {data}\nMaximum: {mx}; Minimum: {mn}; comparisons: {c}")
    ordered=sorted(data)
    for target in (19, 6):
        idx, comps=binary_search(ordered,target)
        print(f"Binary search target {target}: index={idx}, comparisons={comps}")
