The PNG in this folder is the generated console-output capture from the actual Q7 program run.
For final academic submission, students may also add their own IDE/terminal screenshots if required by the instructor.
