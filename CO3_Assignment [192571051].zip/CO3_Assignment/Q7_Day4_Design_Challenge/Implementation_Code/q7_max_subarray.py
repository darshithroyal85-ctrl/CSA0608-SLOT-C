def max_subarray_dc(a):
    if not a: raise ValueError("input must not be empty")
    def solve(lo,hi):
        if lo==hi: return a[lo]
        mid=(lo+hi)//2
        left=solve(lo,mid); right=solve(mid+1,hi)
        s=0; best_left=float("-inf")
        for i in range(mid,lo-1,-1):
            s+=a[i]; best_left=max(best_left,s)
        s=0; best_right=float("-inf")
        for i in range(mid+1,hi+1):
            s+=a[i]; best_right=max(best_right,s)
        return max(left,right,best_left+best_right)
    return solve(0,len(a)-1)
def max_subarray_linear(a):
    best=ending=a[0]
    for x in a[1:]:
        ending=max(x,ending+x); best=max(best,ending)
    return best
if __name__=="__main__":
    data=[-2,1,-3,4,-1,2,1,-5,4]
    print("Q7 Day-4 Design Challenge: Maximum Subarray Sum")
    print("Input:",data)
    print("Divide-and-Conquer result:",max_subarray_dc(data))
    print("Linear baseline result:",max_subarray_linear(data))
    print("Correct:",max_subarray_dc(data)==max_subarray_linear(data))
    print("Recurrence: T(n)=2T(n/2)+O(n); complexity O(n log n).")
