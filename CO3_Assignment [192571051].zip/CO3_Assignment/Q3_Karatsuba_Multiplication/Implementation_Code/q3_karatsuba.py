def karatsuba(x,y):
    if x<10 or y<10: return x*y
    n=max(len(str(x)),len(str(y))); half=n//2; p=10**half
    a,b=divmod(x,p); c,d=divmod(y,p)
    z0=karatsuba(b,d); z2=karatsuba(a,c)
    z1=karatsuba(a+b,c+d)-z2-z0
    return z2*p*p+z1*p+z0
if __name__=="__main__":
    x,y=12345678,87654321
    print("Q3 Karatsuba Multiplication")
    print(f"x={x}, y={y}")
    print("Standard result:",x*y)
    print("Karatsuba result:",karatsuba(x,y))
    print("Correct:",x*y==karatsuba(x,y))
    print("Recurrence: T(n)=3T(n/2)+O(n); complexity O(n^(log2 3)) ≈ O(n^1.585).")
