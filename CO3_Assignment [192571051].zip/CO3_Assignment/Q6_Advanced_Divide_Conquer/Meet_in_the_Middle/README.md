# Meet-in-the-Middle Subset Sum
Implementation: `../Implementation_Code/q6_median_mitm.py`, functions `subset_sums` and `mitm_subset_sum`.
The input is divided into two halves. All subset sums are generated for each half, then complementary sums are searched.
