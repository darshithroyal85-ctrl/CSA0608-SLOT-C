# Median of Medians
Implementation: `../Implementation_Code/q6_median_mitm.py`, function `median_of_medians_select(a, k)`.
Input k is 1-based. The implementation groups values into groups of five, selects a median pivot, partitions values, and recurses into the relevant partition.
