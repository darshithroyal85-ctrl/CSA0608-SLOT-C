from itertools import combinations
def median_of_medians_select(a,k):
    # k is 1-based
    if not 1<=k<=len(a): raise ValueError("k out of range")
    if len(a)<=5: return sorted(a)[k-1]
    groups=[sorted(a[i:i+5]) for i in range(0,len(a),5)]
    medians=[g[len(g)//2] for g in groups]
    pivot=median_of_medians_select(medians,(len(medians)+1)//2)
    low=[x for x in a if x<pivot]; eq=[x for x in a if x==pivot]; high=[x for x in a if x>pivot]
    if k<=len(low): return median_of_medians_select(low,k)
    if k<=len(low)+len(eq): return pivot
    return median_of_medians_select(high,k-len(low)-len(eq))
def subset_sums(nums):
    mid=len(nums)//2; left,right=nums[:mid],nums[mid:]
    sums1=[sum(c) for r in range(len(left)+1) for c in combinations(left,r)]
    sums2=[sum(c) for r in range(len(right)+1) for c in combinations(right,r)]
    return sums1,sums2
def mitm_subset_sum(nums,target):
    a,b=subset_sums(nums); sb=set(b)
    return any(target-x in sb for x in a)
if __name__=="__main__":
    data=[9,1,7,3,11,5,2,8,6]
    print("Q6 Advanced Divide-and-Conquer")
    print("Data:",data)
    print("5th smallest (Median of Medians):",median_of_medians_select(data,5))
    nums=[3,34,4,12,5,2]; target=9
    print(f"Meet-in-the-Middle subset sum {target} in {nums}:",mitm_subset_sum(nums,target))
    print("Selection worst case: O(n); subset-sum Meet-in-the-Middle: O(2^(n/2)) time/space, approximately.")
