def add(A,B): return [[A[i][j]+B[i][j] for j in range(len(A))] for i in range(len(A))]
def sub(A,B): return [[A[i][j]-B[i][j] for j in range(len(A))] for i in range(len(A))]
def conventional(A,B):
    n=len(A)
    return [[sum(A[i][k]*B[k][j] for k in range(n)) for j in range(n)] for i in range(n)]
def strassen(A,B):
    n=len(A)
    if n<=2: return conventional(A,B)
    m=n//2
    a11=[r[:m] for r in A[:m]]; a12=[r[m:] for r in A[:m]]
    a21=[r[:m] for r in A[m:]]; a22=[r[m:] for r in A[m:]]
    b11=[r[:m] for r in B[:m]]; b12=[r[m:] for r in B[:m]]
    b21=[r[:m] for r in B[m:]]; b22=[r[m:] for r in B[m:]]
    p1=strassen(add(a11,a22),add(b11,b22))
    p2=strassen(add(a21,a22),b11)
    p3=strassen(a11,sub(b12,b22))
    p4=strassen(a22,sub(b21,b11))
    p5=strassen(add(a11,a12),b22)
    p6=strassen(sub(a21,a11),add(b11,b12))
    p7=strassen(sub(a12,a22),add(b21,b22))
    c11=add(sub(add(p1,p4),p5),p7)
    c12=add(p3,p5); c21=add(p2,p4)
    c22=add(sub(add(p1,p3),p2),p6)
    top=[c11[i]+c12[i] for i in range(m)]
    bottom=[c21[i]+c22[i] for i in range(m)]
    return top+bottom
def pad(A,n):
    old=len(A); return [row+[0]*(n-old) for row in A]+[[0]*n for _ in range(n-old)]
def crop(A,n): return [row[:n] for row in A[:n]]
if __name__=="__main__":
    A=[[1,2,3],[4,5,6],[7,8,9]]
    B=[[9,8,7],[6,5,4],[3,2,1]]
    n=1
    while n<len(A): n*=2
    S=crop(strassen(pad(A,n),pad(B,n)),len(A))
    C=conventional(A,B)
    print("Q4 Strassen Matrix Multiplication")
    print("Conventional:",C)
    print("Strassen (padded then cropped):",S)
    print("Correct:",C==S)
    print("Recurrence: T(n)=7T(n/2)+O(n^2); complexity O(n^(log2 7)) ≈ O(n^2.807).")
