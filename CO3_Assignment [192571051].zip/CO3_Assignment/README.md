# CO3 Assignment — Divide and Conquer Algorithms

**Student Name:** P DARSHITH  
**Register Number:** 192571051  
**Course Name:** DAA  
**Course Code:** CSA0608

This repository follows the supplied CO3 Assignment 3 requirements and the simple repository/report pattern of the supplied ZIP reference. It includes Q1–Q7 pseudocode, Python implementations, captured program output, and report documents.

## Repository structure
- `Q1_MaxMin_Binary_Search/` — maximum/minimum and binary search
- `Q2_MergeSort_QuickSort/` — merge sort and quick sort comparison
- `Q3_Karatsuba_Multiplication/` — standard and Karatsuba multiplication
- `Q4_Strassen_Matrix_Multiplication/` — conventional and Strassen matrix multiplication
- `Q5_Divide_Conquer_Closest_Pair/` — brute-force and D&C closest pair
- `Q6_Advanced_Divide_Conquer/` — Median of Medians and Meet-in-the-Middle subset sum
- `Q7_Day4_Design_Challenge/` — maximum subarray sum design challenge
- `Final_Report/` — assignment report and contribution record

## Run
Requires Python 3.8+; no third-party Python packages are required to run the algorithms.

```bash
python Q1_MaxMin_Binary_Search/Implementation_Code/q1_maxmin_binary_search.py
python Q2_MergeSort_QuickSort/Implementation_Code/q2_sorting.py
python Q3_Karatsuba_Multiplication/Implementation_Code/q3_karatsuba.py
python Q4_Strassen_Matrix_Multiplication/Implementation_Code/q4_strassen.py
python Q5_Divide_Conquer_Closest_Pair/Implementation_Code/q5_closest_pair.py
python Q6_Advanced_Divide_Conquer/Implementation_Code/q6_median_mitm.py
python Q7_Day4_Design_Challenge/Implementation_Code/q7_max_subarray.py
```

## Complexity summary
| Algorithm | Expected / worst-case time |
|---|---|
| Max/Min D&C | O(n) |
| Binary Search | O(log n) |
| Merge Sort | O(n log n) |
| Quick Sort | Average O(n log n), worst O(n²) |
| Karatsuba | O(n^log₂3) ≈ O(n^1.585) |
| Strassen | O(n^log₂7) ≈ O(n^2.807) |
| Closest Pair D&C | O(n log n) |
| Median of Medians | O(n) worst case |
| Meet-in-the-Middle subset sum | O(2^(n/2)) time and space |
| Maximum Subarray D&C | O(n log n) |

## Important submission note
The execution-output PNGs are generated from actual program runs in this package; they are console-output captures rather than photographs of a physical terminal. Contribution records and Q7 independent proposals are provided as editable drafts. Both partners should review the work, replace any illustrative Student B details with the actual partner's name, and ensure the contribution record reflects work actually completed before submission.
