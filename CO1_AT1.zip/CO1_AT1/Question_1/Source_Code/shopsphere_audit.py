"""ShopSphere Scalability Audit - CO1_AT1 / Question_1
Brute-force verification of every closed form derived in the report,
followed by the n = 1,000,000 scalability estimates.
"""
import math
from functools import lru_cache

SERVER_RATE = 10**8          # basic operations per second
WINDOW_SEC = 10 * 60         # nightly window = 600 s
N_TODAY = 100_000
N_NEXT = 1_000_000


# ---------- Brute-force counters (used only to verify the formulas) ----------
def m1_count(n):
    c = 0
    for i in range(0, n - 1):
        for j in range(i + 1, n):
            c += 1                      # one title/seller comparison
    return c


def m2_count(n):
    c, i = 0, 1
    while i < n:
        for _ in range(i):
            c += 1                      # one Audit() call
        i *= 2
    return c


@lru_cache(None)
def t_s2(n):                            # T(n)=T(n/2)+1, T(1)=1
    return 1 if n == 1 else t_s2(n // 2) + 1


@lru_cache(None)
def t_m4_cur(n):                        # T(n)=4T(n/2)+n, T(1)=1
    return 1 if n == 1 else 4 * t_m4_cur(n // 2) + n


@lru_cache(None)
def t_m4_new(n):                        # T(n)=2T(n/2)+n, T(1)=1
    return 1 if n == 1 else 2 * t_m4_new(n // 2) + n


@lru_cache(None)
def t_m5(n):                            # T(n)=2T(n/2)+n*log2(n), T(1)=1
    return 1 if n == 1 else 2 * t_m5(n // 2) + n * int(math.log2(n))


# ---------- Closed forms derived in the report ----------
def m1_formula(n): return n * (n - 1) // 2
def m2_formula(n): return 2 ** math.ceil(math.log2(n)) - 1
def s2_formula(n): return math.floor(math.log2(n)) + 1
def m4_cur_formula(n): return 2 * n * n - n
def m4_new_formula(n): return n * math.log2(n) + n
def m5_formula(n):
    L = math.log2(n)
    return n * L * (L + 1) / 2 + n
def report_cost(n): return 3 * n * n + 10 * n * math.log2(n) + 50


def s1_average(n, p): return p * (n + 1) / 2 + (1 - p) * n


def fmt_time(sec):
    if sec < 1e-3:
        return f"{sec:.3e} s"
    if sec < 60:
        return f"{sec:.4f} s"
    return f"{sec:,.2f} s  ({sec / 60:,.2f} min = {sec / 3600:.2f} h)"


def main():
    print("=" * 74)
    print("SHOPSPHERE SCALABILITY AUDIT")
    print(f"Server speed: {SERVER_RATE:,} ops/s | Nightly window: {WINDOW_SEC} s "
          f"= {WINDOW_SEC * SERVER_RATE:,} ops")
    print("=" * 74)

    print("\n[1] VERIFICATION OF CLOSED FORMS (brute force vs formula)")
    print("-" * 74)
    for n in (4, 10, 100, 1000):
        assert m1_count(n) == m1_formula(n)
    print("M1  n(n-1)/2 verified by nested-loop count for n = 4, 10, 100, 1000")
    print(f"M1  n=1000 -> {m1_count(1000):,} comparisons")
    for n in (5, 100, 1000, 1024):
        assert m2_count(n) == m2_formula(n)
    print(f"M2  n=1024 -> simulated {m2_count(1024)} Audit ops; formula n-1 = {1024 - 1}")
    for n in (1, 2, 8, 1024, 2 ** 20):
        assert t_s2(n) == int(math.log2(n)) + 1
    print(f"S2  T(1024) = {t_s2(1024)} = log2(1024)+1")
    for n in (2, 16, 1024):
        assert t_m4_cur(n) == m4_cur_formula(n)
        assert t_m4_new(n) == m4_new_formula(n)
        assert t_m5(n) == round(m5_formula(n))
    print(f"M4  current  T(1024) = {t_m4_cur(1024):,} = 2n^2 - n")
    print(f"M4  proposed T(1024) = {t_m4_new(1024):,} = n log2 n + n")
    print(f"M5  T(1024) = {t_m5(1024):,} = n*log2(n)*(log2(n)+1)/2 + n")

    print("\n[2] BEST / AVERAGE / WORST CASES (n = 1,000,000)")
    print("-" * 74)
    n = N_NEXT
    print(f"S1 best = 1 | worst = {n:,} | average (p=0.5) = {s1_average(n, 0.5):,.2f}")
    print(f"S2 best = 1 | worst = {s2_formula(n)} | average ~ log2(n)-1 = {math.log2(n) - 1:.2f}")

    print("\n[3] GROWTH: n = 100,000 (today) vs n = 1,000,000 (next year)")
    print("-" * 74)
    rows = [
        ("M1 Duplicate detector", m1_formula),
        ("M2 Rate limiter", m2_formula),
        ("S2 Binary search (per query)", s2_formula),
        ("M4 Current design", m4_cur_formula),
        ("M4 Proposed design", m4_new_formula),
        ("M5 Sales analytics", m5_formula),
        ("Nightly report generator", report_cost),
    ]
    for name, fn in rows:
        a, b = fn(N_TODAY), fn(N_NEXT)
        print(f"{name:30s} {a:>18,.0f} -> {b:>20,.0f}   x{b / a:,.1f}")

    print("\n[4] SCALABILITY DECISION AT n = 1,000,000")
    print("-" * 74)
    for name, fn in rows:
        ops = fn(N_NEXT)
        sec = ops / SERVER_RATE
        verdict = "MEETS window" if sec <= WINDOW_SEC else "FAILS window"
        print(f"{name}\n   operations = {ops:,.0f}\n   time       = {fmt_time(sec)}\n   -> {verdict}")

    print("\nRECOMMENDATIONS")
    print("- Redesign M1: hash on (title, seller) -> O(n) expected time.")
    print("- Adopt the M4 redesign (no replication) -> Theta(n log n).")
    print("- Redesign the quadratic report generator.")
    print("- Keep M2, S2 and M5 (M5 could be improved to n log n by sorting once).")


if __name__ == "__main__":
    main()
