# CO1_AT1 – Scalability Audit of "ShopSphere"

Application-based problem on algorithm analysis (time/space complexity, recurrences,
Master Theorem, asymptotic proofs and scalability decisions) for an online shopping platform.

## Repository structure

```
CO1_AT1/
├── Question_1/
│   ├── Source_Code/
│   │   └── shopsphere_audit.py
│   └── Report/
│       ├── ShopSphere_Scalability_Audit_Report.docx
│       └── program_output.txt
└── README.md
```

## How to run

Requires Python 3.8+ (standard library only).

```bash
cd Question_1/Source_Code
python shopsphere_audit.py
```

The program:
1. Brute-force counts the operations of M1 and M2 and checks them against the closed forms.
2. Evaluates the recurrences (S2, M4 current/redesign, M5) and checks them against their solutions.
3. Prints best/average/worst cases for S1 and S2.
4. Estimates operations and running time for n = 100,000 and n = 1,000,000 at 10^8 operations/second
   and compares each against the 10-minute nightly window.

## Summary of results

| Module | Complexity | Ops at n = 10^6 | Time | Meets 10-min window |
|---|---|---|---|---|
| M1 Duplicate detector | Θ(n²), n(n-1)/2 | 4.99999 x 10^11 | ~5,000 s (83 min) | No |
| M2 Rate limiter | Θ(n), 2^⌈log₂n⌉ - 1 | 1,048,575 | ~0.01 s | Yes |
| S2 Binary search | Θ(log n), ⌊log₂n⌋ + 1 | 20 per query | ~2 x 10^-7 s | Yes |
| M4 current design | Θ(n²), 2n² - n | ~2.0 x 10^12 | ~20,000 s (5.6 h) | No |
| M4 proposed design | Θ(n log n), n log₂n + n | ~2.09 x 10^7 | ~0.21 s | Yes |
| M5 Sales analytics | Θ(n log² n) | ~2.10 x 10^8 | ~2.1 s | Yes |
| Report generator | Θ(n²), 3n² + 10n log₂n + 50 | ~3.0 x 10^12 | ~30,000 s (8.3 h) | No |

## Recommendations

- Redesign M1 with hash-based grouping on (title, seller): Θ(n) expected time.
- Adopt the M4 redesign (no replication): Θ(n²) to Θ(n log n).
- Redesign the quadratic report generator.
- Keep M2; use S2 (binary search) instead of S1; keep M5 (optionally sort once to reach Θ(n log n)).

## Report

The full derivations for parts (a)–(g), with screenshots of the source code and output,
are in `Question_1/Report/ShopSphere_Scalability_Audit_Report.docx`.
