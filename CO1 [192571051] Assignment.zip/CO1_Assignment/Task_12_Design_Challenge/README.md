# Task 12 – Day-4 Design Challenge
## A. Impact analysis
The requirement is 50,000 searches/hour on 1,000,000 records, approximately 13.89 searches/second averaged across an hour. Searches greatly outnumber daily updates, so a one-time index build and modest incremental update cost can be amortized over many reads.

## B. Evaluate original design
A linear scan may require up to 1,000,000 comparisons per miss; at 50,000 misses/hour that could be up to 50 billion comparisons/hour. Binary search needs about 20 comparisons per million-record lookup (about one million comparisons/hour for 50,000 requests, order-of-magnitude estimate). Hash lookup is expected constant-time, with O(n) initial index build.

## C. Decision: MODIFY / REDESIGN
Use a persistent hash index keyed by registration number, or the database's equivalent indexed primary key. Build/load once and insert new daily records into the index. Expected complexity: O(n) initial build, O(1) expected lookup and insertion, O(n) memory; worst-case hash lookup O(n), mitigated by a robust implementation. A balanced B-tree/index is an alternative where database durability, range queries and predictable logarithmic bounds matter.

## D. Evidence-based defence
The benchmark records one million comparisons for linear search at n=1,000,000, approximately 19 recursive binary comparisons for the absent key, and one logical hash lookup. Hash construction was measured separately and grows with n; daily updates mean the index cost is amortized across 50,000 hourly searches. The decision is based on operation counts and the read/update pattern, not solely on Big-O. For production, verify p95/p99 latency, concurrent throughput, memory footprint, index persistence and failure recovery on target hardware.
