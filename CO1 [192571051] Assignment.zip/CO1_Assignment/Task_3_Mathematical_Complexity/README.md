# Task 3 – Mathematical Complexity
Let n be the number of records.

**Linear search:** if the key is absent, comparisons C(n)=Σ(i=1 to n)1=n. If the key is equally likely to be at any position and present, E[C]=(1+...+n)/n=(n+1)/2. Thus query time is Θ(n). No preprocessing.

**Recursive binary search:** after each comparison, at most half the candidate records remain. For n records, after k halvings, n/2^k ≤ 1, so k ≥ log₂n. The number of comparisons is bounded by floor(log₂n)+1 for a successful path (and at most about ceil(log₂(n+1)) for an unsuccessful path). Query time Θ(log n). If sorting is required, preprocessing is Θ(n log n), making one-off total Θ(n log n); for q queries after sorting, Θ(n log n + q log n).

**Hash table:** build index expected Θ(n), memory Θ(n); each query expected Θ(1), worst Θ(n) with pathological collisions. For q queries, expected total Θ(n+q). Daily batch additions can be inserted into the index in expected Θ(k) for k new records.
