# CO1_Assignment — Student Registration Number Search

**Course:** CSA06 Design and Analysis of Algorithms  
**Assignment:** Assignment 1 – CO1  
**Scenario:** Search registration numbers across 1,000 to 1,000,000 records.

## Algorithms
1. Iterative linear search — O(n), no preprocessing.
2. Recursive binary search — O(log n) per query on sorted data; sorting initially costs O(n log n).
3. Hash-table lookup — expected O(1) per query after expected O(n) index construction.

## Run
Requires Python 3.8 or newer.

```bash
python Task_8_Implementation_Testing/Source_Code/student_search_benchmark.py
```

The script prints the benchmark and writes `Task_9_Experimental_Performance/benchmark_results.csv`. It tests an absent key to measure the full linear scan and includes correctness checks for first/middle/last/missing keys. Times depend on your computer; rerun on your own machine for submission evidence.

## Repository map
- `Task_1_Algorithm_Design/` — pseudocode and strategy choice
- `Task_2_Basic_Operation/` — dominant operation
- `Task_3_Mathematical_Complexity/` — mathematical derivations
- `Task_4_Case_Analysis/` — best/average/worst cases
- `Task_5_Asymptotic_Analysis/` — O, Ω, Θ
- `Task_6_Recurrence_Formulation/` and `Task_7_Recurrence_Solution/` — recurrence and solution
- `Task_8_Implementation_Testing/Source_Code/` — runnable Python implementation
- `Task_9_Experimental_Performance/` — CSV and captured output
- `Task_10_Theory_vs_Experiment/` — interpretation
- `Task_11_Final_Recommendation/` — recommendation
- `Task_12_Design_Challenge/` — 50,000 searches/hour analysis
- `Report/` — generated report, figures, evidence and documentation

## Main conclusion
For one million records and 50,000 searches/hour with additions only daily, a hash index is recommended for expected constant-time lookup. Keep its O(n) build cost and memory footprint in the design; use a balanced database index when ordered queries or stronger worst-case guarantees are required.
