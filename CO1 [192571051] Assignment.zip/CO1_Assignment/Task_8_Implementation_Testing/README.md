# Task 8 – Implementation and Testing
Source: `Source_Code/student_search_benchmark.py` (Python 3.8+, standard library only).
Run from the repository root:

```bash
python Task_8_Implementation_Testing/Source_Code/student_search_benchmark.py
```

The script tests n=1,000, 10,000, 100,000, 1,000,000. Registration numbers are unique and sorted to support binary search. It searches an absent key for a worst-case linear scan, times searches with `time.perf_counter`, reports median time and comparisons/probes, and separately times hash index construction. It also verifies first, middle, last, and missing keys on a small test array.
