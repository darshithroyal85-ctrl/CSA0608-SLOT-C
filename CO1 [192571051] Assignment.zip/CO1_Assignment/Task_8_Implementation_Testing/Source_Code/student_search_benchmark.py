"""
CO1 Assignment: Student Registration Number Search Benchmark
Algorithms:
1. Iterative linear search (no preprocessing)
2. Recursive binary search (requires sorted registration numbers)
3. Hash-table lookup (build index once; expected O(1) query)
Dataset sizes: 1,000; 10,000; 100,000; 1,000,000.
The benchmark searches for an absent key to expose the full scan for linear search.
Times are machine-dependent; run this script on your own computer and retain its output.
"""
import csv, time, statistics, os, random
from pathlib import Path

SIZES = [1_000, 10_000, 100_000, 1_000_000]
REPEATS = 15

def linear_search(data, target):
    comparisons = 0
    for i, value in enumerate(data):
        comparisons += 1
        if value == target:
            return i, comparisons
    return -1, comparisons

def recursive_binary_search(data, target, low=0, high=None, counter=None):
    if high is None:
        high = len(data) - 1
    if counter is None:
        counter = [0]
    if low > high:
        return -1, counter[0]
    mid = (low + high) // 2
    counter[0] += 1
    if data[mid] == target:
        return mid, counter[0]
    if target < data[mid]:
        return recursive_binary_search(data, target, low, mid - 1, counter)
    return recursive_binary_search(data, target, mid + 1, high, counter)

def build_hash_index(data):
    return {value: i for i, value in enumerate(data)}

def hash_search(index, target):
    # One dictionary membership probe is counted as one logical lookup.
    return index.get(target, -1), 1

def timed(fn, repeats=REPEATS):
    samples=[]
    result=None
    for _ in range(repeats):
        t0=time.perf_counter()
        result=fn()
        samples.append(time.perf_counter()-t0)
    return statistics.median(samples), result

def main():
    out_dir=Path(__file__).resolve().parents[2] / 'Task_9_Experimental_Performance'
    out_dir.mkdir(parents=True, exist_ok=True)
    csv_path=out_dir/'benchmark_results.csv'
    rows=[]
    print("STUDENT REGISTRATION SEARCH BENCHMARK")
    print("Target is absent (worst-case linear scan); times are medians over", REPEATS, "runs")
    print(f"{'n':>10} {'Algorithm':<25} {'Build seconds':>14} {'Search seconds':>15} {'Comparisons':>14} {'Found':>8}")
    for n in SIZES:
        data=list(range(1_000_001, 1_000_001+n)) # sorted, unique IDs
        target=-1
        # Linear search
        t, result=timed(lambda: linear_search(data,target))
        idx, comps=result
        rows.append([n,'Iterative linear search',0.0,t,comps,idx!=-1])
        print(f"{n:>10,} {'Linear search':<25} {0.0:>14.6f} {t:>15.6f} {comps:>14,} {str(idx!=-1):>8}")
        # Recursive binary search
        t, result=timed(lambda: recursive_binary_search(data,target))
        idx, comps=result
        rows.append([n,'Recursive binary search',0.0,t,comps,idx!=-1])
        print(f"{n:>10,} {'Recursive binary':<25} {0.0:>14.6f} {t:>15.6f} {comps:>14,} {str(idx!=-1):>8}")
        # Hash index build measured separately; search only after construction
        build_t, index=timed(lambda: build_hash_index(data), repeats=3)
        # timed() returns last result, median build duration
        t, result=timed(lambda: hash_search(index,target))
        idx, comps=result
        rows.append([n,'Hash table lookup',build_t,t,comps,idx!=-1])
        print(f"{n:>10,} {'Hash lookup':<25} {build_t:>14.6f} {t:>15.6f} {comps:>14,} {str(idx!=-1):>8}")
    with csv_path.open('w',newline='',encoding='utf-8') as f:
        w=csv.writer(f); w.writerow(['n','algorithm','index_build_seconds','search_median_seconds','comparisons_or_probes','found']); w.writerows(rows)
    # Correctness cases: first, middle, last, missing
    sample=list(range(100,200))
    h=build_hash_index(sample)
    tests=[(100,True),(150,True),(199,True),(999,False)]
    for target,expected in tests:
        assert (linear_search(sample,target)[0] != -1)==expected
        assert (recursive_binary_search(sample,target)[0] != -1)==expected
        assert (hash_search(h,target)[0] != -1)==expected
    print("\\nCorrectness tests passed: first, middle, last, and missing key for all three algorithms.")
    print("CSV written to:",csv_path)
if __name__=='__main__':
    main()
