# Task 6 – Recurrence Formulation
For recursive binary search, n is the current number of candidate records. One comparison and constant bookkeeping occur outside the recursive call, and exactly one subproblem of size at most n/2 is searched. Base case: n=0 (empty interval) or n=1.

T(n) = T(⌊n/2⌋) + c for n > 1; T(0)=c₀. There is one recursive call, not two.
