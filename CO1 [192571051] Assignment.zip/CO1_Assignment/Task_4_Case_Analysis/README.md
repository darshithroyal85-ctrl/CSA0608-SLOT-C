# Task 4 – Best, Average, Worst Cases
| Algorithm | Best case | Average case | Worst case |
|---|---|---|---|
| Linear | Θ(1), key first | successful uniform position: Θ(n); absent: n comparisons | Θ(n), key last or absent |
| Recursive binary | Θ(1), middle key | Θ(log n) | Θ(log n) |
| Hash lookup | expected Θ(1) | expected Θ(1) with good hashing/load factor | Θ(n) if many collisions |

Linear search differs greatly according to key position. Binary search halves the interval regardless of position, so its asymptotic best-to-worst difference is one comparison versus logarithmic comparisons. Hashing has expected constant lookup but must account for collision-heavy worst cases.
