# Task 2 – Basic Operation
- **Linear search:** equality comparison `A[i] == key`; each record can be checked, up to n times.
- **Recursive binary search:** comparison of key with the middle registration number; the search interval is halved after each comparison.
- **Hash lookup:** hash-table probe/key equality check. Expected constant probes under a good hash function and controlled load factor; collisions can increase work.

These operations are useful because their counts track the dominant growth of the search, independent of machine speed.
