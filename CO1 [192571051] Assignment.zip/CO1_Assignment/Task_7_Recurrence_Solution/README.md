# Task 7 – Recurrence Solution (Iteration)
For powers of two, simplify to T(n)=T(n/2)+c, T(1)=d.

T(n)=T(n/2)+c
=T(n/4)+2c
=T(n/8)+3c
=…=T(n/2^k)+kc.

Stop when n/2^k=1, so k=log₂n. Therefore T(n)=d+c log₂n=Θ(log n). The Master Theorem gives the same result with a=1, b=2, f(n)=Θ(1), and n^(log_b a)=1. The logarithmic result follows because each call halves the search interval.
