# Task 1 – Algorithm Design

## A. Iterative linear search
Scan registration numbers from the first record to the last until the key is found. No preprocessing is needed; works on unsorted data.

```text
LINEAR-SEARCH(A, key)
  for i = 0 to length(A)-1
    if A[i] == key: return i
  return NOT_FOUND
```

## B. Recursive binary search
Requires records sorted by registration number. Compare with the middle record and recursively continue in only the half that can contain the key.

```text
BINARY-SEARCH(A, key, low, high)
  if low > high: return NOT_FOUND
  mid = floor((low+high)/2)
  if A[mid] == key: return mid
  if key < A[mid]: return BINARY-SEARCH(A,key,low,mid-1)
  return BINARY-SEARCH(A,key,mid+1,high)
```

## C. Hash-table lookup
Build a dictionary mapping each registration number to its record position. A lookup uses the key to access the bucket directly on average.

```text
BUILD-INDEX(A)
  H = empty hash table
  for each record A[i]: H[A[i]] = i
  return H
HASH-SEARCH(H,key)
  if key in H: return H[key]
  return NOT_FOUND
```

**Why these are distinct:** sequential scan, divide-and-conquer over sorted data, and hashing/indexing. Hash preprocessing is O(n) expected and should be amortized over many queries. Binary search sorting cost is O(n log n) if the original data is unsorted; if already maintained sorted, query cost is O(log n).
