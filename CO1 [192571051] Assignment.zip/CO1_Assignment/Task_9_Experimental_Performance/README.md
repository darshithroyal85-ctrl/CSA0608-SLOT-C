# Task 9 – Experimental Performance
- `benchmark_results.csv`: measured data, including index build time and median search time.
- `benchmark_console_output.txt`: captured program output.
- `../Report/Tables_and_Graphs/`: operation-count, search-time, and hash-build-time graphs.

Measurements are environment-specific and may vary by CPU, Python version, system load, and timer resolution. Hash lookup durations can be below the practical resolution of the timer; treat its logical probe count as the more stable measure. Run the benchmark locally before submission and replace/append your own measurements if needed.
