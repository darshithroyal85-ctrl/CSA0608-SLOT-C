# Task 5 – Asymptotic Analysis
- Linear search: best Ω(1), worst O(n), average Θ(n).
- Recursive binary search on sorted data: best Ω(1), worst O(log n), and worst-case Θ(log n).
- Hash lookup: expected Θ(1), worst O(n); index construction expected Θ(n).

At n=1,000,000, a linear unsuccessful search checks one million keys; binary search needs roughly 20 comparisons; hash lookup generally needs a small constant number of probes. Big-O describes growth, not exact wall-clock time or memory usage.
