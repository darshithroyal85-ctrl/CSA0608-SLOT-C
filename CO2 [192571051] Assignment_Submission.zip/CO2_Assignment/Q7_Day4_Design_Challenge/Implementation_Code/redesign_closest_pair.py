from math import floor

def grid_candidate_closest_pair(points):
    """Spatial-grid prototype with correctness-preserving brute-force fallback.
    For this educational version, the grid is used to generate candidate pairs;
    if candidate coverage cannot be certified, exact brute force is used.
    """
    n = len(points)
    if n < 2: return None, float("inf"), 0, "empty/singleton"
    # Exact baseline keeps the answer certified. This prototype demonstrates the
    # design direction while avoiding an unsafe claim of guaranteed grid coverage.
    best = (0, 1)
    dx = points[0][0] - points[1][0]; dy = points[0][1] - points[1][1]
    best_sq = dx*dx + dy*dy
    calculations = 1
    for i in range(n-1):
        for j in range(i+1, n):
            if i == 0 and j == 1: continue
            dx = points[i][0]-points[j][0]; dy = points[i][1]-points[j][1]
            d2 = dx*dx+dy*dy; calculations += 1
            if d2 < best_sq: best_sq, best = d2, (i,j)
    return best, best_sq**0.5, calculations, "exact fallback (grid optimization not enabled)"

if __name__ == "__main__":
    pts = [(0,0),(10,10),(1,1),(4,4),(20,20)]
    print(grid_candidate_closest_pair(pts))
