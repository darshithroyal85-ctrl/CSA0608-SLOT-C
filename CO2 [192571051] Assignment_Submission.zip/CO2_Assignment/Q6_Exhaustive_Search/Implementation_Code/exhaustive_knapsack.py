from itertools import combinations

def exhaustive_knapsack(items, capacity):
    """items are dictionaries with id, weight, value; examine all subsets."""
    n = len(items)
    best_value, best_subset, feasible_count = 0, [], 0
    subsets_examined = 0
    for mask in range(1 << n):
        subsets_examined += 1
        weight = value = 0
        chosen = []
        for i in range(n):
            if mask & (1 << i):
                weight += items[i]["weight"]
                value += items[i]["value"]
                chosen.append(items[i]["id"])
        if weight <= capacity:
            feasible_count += 1
            if value > best_value:
                best_value, best_subset = value, chosen
    return {"chosen_ids": best_subset, "total_value": best_value,
            "subsets_examined": subsets_examined, "feasible_subsets": feasible_count}

def growth_table(ns=(8, 12, 16, 20)):
    return [{"n": n, "subsets": 2**n} for n in ns]

if __name__ == "__main__":
    items = [
        {"id":"P1","weight":2,"value":6}, {"id":"P2","weight":3,"value":10},
        {"id":"P3","weight":4,"value":12}, {"id":"P4","weight":1,"value":3},
        {"id":"P5","weight":5,"value":15},
    ]
    print(exhaustive_knapsack(items, 7))
    print(growth_table())
