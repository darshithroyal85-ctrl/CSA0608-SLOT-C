# CO2 Assignment — Brute Force and Exhaustive Search

This repository follows the supplied CSA06 Assignment 2 CO2 brief. It contains Q1–Q7 pseudocode,
Python implementations, a consolidated report, test datasets, operation-count experiments,
graphs and execution-output screenshots.

## Run
Python 3.10+ recommended. From the repository root:
```bash
python Q1_Sorting_Algorithms/Implementation_Code/sorting_algorithms.py
python Q2_Sequential_Search/Implementation_Code/sequential_search.py
python Q3_Brute_Force_String_Matching/Implementation_Code/brute_force_match.py
python Q4_Brute_Force_Closest_Pair/Implementation_Code/closest_pair.py
python Q5_Brute_Force_Convex_Hull/Implementation_Code/convex_hull.py
python Q6_Exhaustive_Search/Implementation_Code/exhaustive_knapsack.py
python Q7_Day4_Design_Challenge/Implementation_Code/redesign_closest_pair.py
```

## Complexity summary
- Q1: Selection O(n²) comparisons; Bubble O(n²) worst and O(n) best with early exit; Insertion O(n²) worst and O(n) best.
- Q2: Sequential search O(n), O(1) auxiliary space.
- Q3: Brute-force matching O((n-m+1)m), O(1) auxiliary space excluding match positions.
- Q4: Closest pair O(n²) time, O(1) auxiliary space.
- Q5: Brute-force convex hull O(n³) orientation work in the worst case.
- Q6: Exhaustive knapsack O(n·2ⁿ) time, O(n) working space.
- Q7: Documents the closest-pair bottleneck, objective, trade-offs and validation approach.

The experiment timings are environment-dependent; operation counts are the primary evidence. Replace the sample student details in the report before submission.
