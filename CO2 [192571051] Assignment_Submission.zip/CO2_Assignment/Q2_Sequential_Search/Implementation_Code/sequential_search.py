def sequential_search(records, target):
    """Return index and comparison count; index is None when absent."""
    comparisons = 0
    for i, record in enumerate(records):
        comparisons += 1
        if record["tool_id"] == target:
            return i, comparisons
    return None, comparisons

def demo():
    records = [{"tool_id": f"T-{i:03d}", "technician": f"TECH-{i%7}", "bay": i%4} for i in range(1, 101)]
    cases = [("T-001", "first"), ("T-050", "middle"), ("T-100", "last"), ("T-999", "missing")]
    return [{"query": q, "position": label, "result": sequential_search(records, q)} for q, label in cases]

if __name__ == "__main__":
    for item in demo(): print(item)
