def find_all(text, pattern):
    """Return every match index and number of character comparisons."""
    if pattern == "":
        return list(range(len(text) + 1)), 0
    n, m = len(text), len(pattern)
    hits, comparisons = [], 0
    for i in range(n - m + 1):
        j = 0
        while j < m:
            comparisons += 1
            if text[i+j] != pattern[j]:
                break
            j += 1
        if j == m:
            hits.append(i)
    return hits, comparisons

def demo():
    cases = [
        ("easy_match", "xxALERTyy", "ALERT"),
        ("repeated_prefix_worstish", "A"*30 + "B", "A"*10 + "C"),
        ("overlapping", "ABABAABA", "ABA"),
    ]
    out = []
    for name, text, pattern in cases:
        hits, comps = find_all(text, pattern)
        out.append({"case": name, "text_length": len(text), "pattern": pattern,
                    "hits": hits, "character_comparisons": comps})
    return out

if __name__ == "__main__":
    for row in demo(): print(row)
