def cross(o, a, b):
    return (a[0]-o[0])*(b[1]-o[1]) - (a[1]-o[1])*(b[0]-o[0])

def brute_force_hull(points):
    """Return hull vertices in counter-clockwise order; O(n^3) orientation tests.
    Collinear points on an edge are allowed as candidates, but only extreme endpoints
    are retained in the returned hull.
    """
    pts = sorted(set(tuple(p) for p in points))
    n = len(pts)
    if n <= 1: return pts, 0
    if all(cross(pts[0], pts[-1], p) == 0 for p in pts[1:-1]):
        return [pts[0], pts[-1]], max(0, n-2)
    edges = set()
    tests = 0
    for i in range(n):
        for j in range(i+1, n):
            pos = neg = False
            for k in range(n):
                if k == i or k == j: continue
                tests += 1
                c = cross(pts[i], pts[j], pts[k])
                if c > 0: pos = True
                elif c < 0: neg = True
                if pos and neg: break
            if not (pos and neg):
                edges.add((pts[i], pts[j]))
    # Recover hull vertices from supporting edges, then order around centroid.
    import math
    vertices = sorted({p for edge in edges for p in edge})
    cx = sum(p[0] for p in vertices)/len(vertices)
    cy = sum(p[1] for p in vertices)/len(vertices)
    vertices.sort(key=lambda p: math.atan2(p[1]-cy, p[0]-cx))
    return vertices, tests

def demo():
    cases = {
        "interior_points": [(0,0),(4,0),(4,4),(0,4),(2,2),(1,1)],
        "challenging_concave_cloud": [(0,0),(5,0),(6,2),(4,5),(1,4),(2,2),(3,1),(3,3)],
    }
    return {name: brute_force_hull(points) for name, points in cases.items()}

if __name__ == "__main__":
    for name, result in demo().items(): print(name, result)
