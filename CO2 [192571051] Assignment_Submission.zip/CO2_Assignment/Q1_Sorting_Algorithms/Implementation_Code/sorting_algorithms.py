"""Q1: Selection, Bubble and Insertion Sort with operation counters."""
from dataclasses import dataclass
from typing import List, Callable

@dataclass
class Stats:
    comparisons: int = 0
    swaps: int = 0
    movements: int = 0

def selection_sort(values):
    a = list(values); s = Stats(); n = len(a)
    for i in range(n - 1):
        min_idx = i
        for j in range(i + 1, n):
            s.comparisons += 1
            if a[j] < a[min_idx]:
                min_idx = j
        if min_idx != i:
            a[i], a[min_idx] = a[min_idx], a[i]
            s.swaps += 1
    return a, s

def bubble_sort(values):
    a = list(values); s = Stats(); n = len(a)
    for end in range(n - 1, 0, -1):
        changed = False
        for j in range(end):
            s.comparisons += 1
            if a[j] > a[j + 1]:
                a[j], a[j + 1] = a[j + 1], a[j]
                s.swaps += 1
                changed = True
        if not changed:
            break
    return a, s

def insertion_sort(values):
    a = list(values); s = Stats()
    for i in range(1, len(a)):
        key = a[i]; j = i - 1
        while j >= 0:
            s.comparisons += 1
            if a[j] > key:
                a[j + 1] = a[j]
                s.movements += 1
                j -= 1
            else:
                break
        a[j + 1] = key
        s.movements += 1
    return a, s

def run_demo():
    datasets = {
        "nearly_sorted": [1, 2, 3, 5, 4, 6, 7, 8],
        "reverse": [8, 7, 6, 5, 4, 3, 2, 1],
        "edge_duplicates": [4, 4, 4, 4]
    }
    rows = []
    for dname, data in datasets.items():
        for name, fn in [("Selection", selection_sort), ("Bubble", bubble_sort), ("Insertion", insertion_sort)]:
            out, stats = fn(data)
            rows.append({"dataset": dname, "algorithm": name, "input": str(data),
                         "output": str(out), "comparisons": stats.comparisons,
                         "swaps": stats.swaps, "movements": stats.movements})
    return rows

if __name__ == "__main__":
    for row in run_demo():
        print(row)
