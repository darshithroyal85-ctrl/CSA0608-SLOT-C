from math import hypot
from time import perf_counter

def closest_pair(points):
    """Brute-force closest pair, examining each unordered pair once."""
    n = len(points)
    if n < 2:
        return None, float("inf"), 0
    best_pair, best_sq, calculations = None, float("inf"), 0
    for i in range(n - 1):
        for j in range(i + 1, n):
            dx = points[i][0] - points[j][0]
            dy = points[i][1] - points[j][1]
            d_sq = dx*dx + dy*dy
            calculations += 1
            if d_sq < best_sq:
                best_sq, best_pair = d_sq, (i, j)
    return best_pair, best_sq ** 0.5, calculations

def benchmark(sizes=(100, 500, 1000, 2000)):
    import random
    rng = random.Random(42)
    rows = []
    for n in sizes:
        pts = [(rng.random()*10000, rng.random()*10000) for _ in range(n)]
        start = perf_counter()
        pair, dist, count = closest_pair(pts)
        elapsed = perf_counter() - start
        rows.append({"n": n, "pairs": count, "expected_pairs": n*(n-1)//2,
                     "elapsed_seconds": elapsed, "closest_pair_indices": pair, "distance": dist})
    return rows

if __name__ == "__main__":
    print("sample:", closest_pair([(0,0), (5,5), (1,1), (9,9)]))
    for row in benchmark(): print(row)
